#Find the sum of all values
d = {"a": 1, "b": 2, "c": 3}
print(sum(d.values()))
