#Multiply the values of the text file in the URL by two and export the output to a new file
