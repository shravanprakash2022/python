#Create a script that generates a list whose items are products of the original list items multiplied by 10
my_range = range(1, 21)
print([10 * x for x in my_range])
