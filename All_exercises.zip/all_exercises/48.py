#The script is supposed to print a string item if that item is character "l".
#Solution indent everything under an if statement
for letter in "Hello":
    if letter == "e":
    print(letter)
