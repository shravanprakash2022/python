#The script is trying to print out the type of the last character of updated string.
#A: One more bracket is needed to close the print function
print(type("Hey".replace("ey","i")[-1])
