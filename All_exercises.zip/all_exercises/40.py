#Try to find the cause of the error and give a correct example
#A: pow(2,3)
import math
print(math.pow(2))
