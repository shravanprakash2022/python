#Why is the error and how to fix it?

def foo(a=1, b=2):
    return a + b

print(type(foo()))

x = foo() - 1
